﻿using System;

namespace Guess
{
    class Program
    {
        //数当てゲーム
        static void Main(string[] args)
        {
            //当たりの数
            const int answer = 50;

            //ユーザー入力変数、カウンター変数、下限、上限の定義
            int n, i, min = 0, max = 100;//ここでminとmaxを変数として定義しておくことで、再入力時にも範囲を狭めていくことができる

            Console.Write("0から100の間の整数値を当てて下さい。＞");
     
            //カウンター初期条件
            i = 1;
            
            //ヒントを表示するループ
            while (true) 
            {
                //エラー入力がない場合    
                try
                {
                    //ユーザー入力                       
                    n = int.Parse(Console.ReadLine());
                    
                    //nが範囲外の場合
                    if (n < min || n > max)                      
                    {
                        Console.WriteLine("入力値が正しくありません。再入力してください。");
                        Console.Write("{0}から{1}の間の整数値を当てて下さい。＞", min, max);
                        i--;//ヒントのカウンターを減らす
                    }

                    //nが正解の場合
                    else if (n == answer)
                    {
                        Console.WriteLine("おめでとう。{0}回目で当たりました。", i);
                        break;
                    }

                    //n < answer
                    else if (n < answer)
                    {
                        Console.WriteLine("答えはもっと大きいです。");
                        Console.WriteLine();//改行
                        Console.Write("{0}から{1}までの間の数値を当ててください。＞", n + 1, max);

                        //下限の範囲を狭める
                        min = n + 1;
                    }

                    //n > answer
                    else 
                    {
                        Console.WriteLine("答えはもっと小さいです。");
                        Console.WriteLine();//改行
                        Console.Write("{0}から{1}までの間の数値を当ててください。＞", min,  n - 1);

                        //上限の範囲を狭める
                        max = n - 1;
                    }
                    //ヒントの数を計測するために、カウンターを増やす                     
                    i++; 
                }
                    
                //エラー入力がある場合
                catch (FormatException ex) 
                {
                    Console.WriteLine(ex.Message);  
                    break;  
                }
            }

            Console.Write("\n");
            Console.WriteLine("終了するには何かキーを押してください。");
            Console.Read();
        }
    }
}
